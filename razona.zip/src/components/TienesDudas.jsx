import React from 'react';

const TienesDudas = () => {
	return (
		<div
			style={{ backgroundColor: 'white' }}
			class="row justify-content-center align-items-center dudas EvColorGrisLight "
		>
			<div class="col-12 col-md-6  dudas-box p-4">
				<h2 class="font-weight-bold mt-4 mb-4 text-center ">
					¿Tiene dudas o<br /> necesita ayuda?
				</h2>
				<h4 class="font-italic h4 mb-4 text-center">
					Contacte a nuestro equipo de soporte entre 9:00 y 18:00 hrs.
				</h4>
				<div>
					<span class="linespanblack" />
				</div>
			</div>
			<div class="col-12 col-md-6 text-center h5 mt-4 font-weight-bold">
				<p>Teléfono / +56 957065899 </p>
				<p>Email / info@razona.cl </p>
			</div>
		</div>
	);
};

export default TienesDudas;
