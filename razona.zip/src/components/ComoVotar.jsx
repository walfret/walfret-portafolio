import React from 'react';

const ComoVotar = () => {
	return (
		<div class="row justify-content-center EvColorBlue mt-4">
			<div class="col-12 text-center text-white">
				<div class="row">
					<div class="col-12 text-center ">
						<h1 class=" font-weight-bold mt-4 mb-4">¿Cómo se vota?</h1>
					</div>
				</div>
				<div class="row mb-4">
					<div class="col-12 col-sm-4 text-center">
						<p class="como-title mt-4">1. Elegir</p>
						<p class="font-italic h5 vp-75">Marque sus preferencias y cierre el voto</p>
						<img
							src="https://lidermundial.evoting.cl/static/media/elegir_b-01.e44b3c3e.svg"
							class="img-max-300"
							alt="Cómo"
						/>
					</div>
					<div class="col-12 col-sm-4 text-center border-left">
						<p class="como-title mt-4">2. Confirmar</p>
						<p class="font-italic h5 vp-75">Confirme sus respuestas</p>
						<img
							src="https://lidermundial.evoting.cl/static/media/confirmar%20respuestas_b-01.35aac671.svg"
							class="img-max-300"
							alt="Confirmar"
						/>
					</div>
					<div class="col-12 col-sm-4 text-center border-left">
						<p class="como-title mt-4">3. Depositar Voto</p>
						<p class="font-italic h5 vp-75">Deposite el voto con los datos de su cédula de identidad</p>
						<img
							src="https://lidermundial.evoting.cl/static/media/datos%20cedula_b-01.cc3c411a.svg"
							class="img-max-300"
							alt="Votar"
						/>
					</div>
				</div>
			</div>
		</div>
	);
};

export default ComoVotar;
