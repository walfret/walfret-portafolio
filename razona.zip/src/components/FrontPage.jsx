import React from 'react'
import ComoVotar from './ComoVotar'
import SaberMas from './SaberMas'
import TienesDudas from './TienesDudas'
import VotingButton from './VotingButton'

export const FrontPage = () => {
    return (
        <>
    <div style={{ backgroundImage: `url("")`}}>
      <VotingButton />
      </div>
      <ComoVotar />
      <TienesDudas />
      <SaberMas />




      
      </>
    )
}
