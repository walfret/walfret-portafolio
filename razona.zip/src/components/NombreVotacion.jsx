import React from 'react';

const NombreVotacion = () => {
	return (
		<div class="row justify-content-center">
			<div class="col-12 col-sm-11 text-center">
				<h2 class="font-weight-bold">Demo Abierto - Elecciones de Prueba</h2>
				<h3 class="font-italic">RAZONA</h3>
			</div>
		</div>
	);
};

export default NombreVotacion;
