import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

const VotingButton = () => {
	return (
		<div class="row justify-content-center">
			<div class="col-12 col-sm-11  text-center  my-m4 ">
				<Link to="/votacion">
					<a class="boton EvColor">
						<span class="iconvote" />Votar
					</a>
				</Link>
			</div>
		</div>
	);
};

export default VotingButton;
