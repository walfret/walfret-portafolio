import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import { FrontPage } from './FrontPage';
import Header from "./Header";
import LogoInstitucion from './LogoInstitucion';
import Votacion from './Votacion';
import NombreVotacion from './NombreVotacion';


function App() {
  return (
    <Router>
    <div class="container-fluid">
      <Header />
      <LogoInstitucion />
      <NombreVotacion />
     <Switch>
     <Route path="/" exact>
            <FrontPage />
          </Route>
          <Route path="/votacion" exact>
            <Votacion />
          </Route>
        </Switch>
        
        </div>
    </Router>
  );
}

export default App;
