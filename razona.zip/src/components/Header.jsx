import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

const Header = () => {
	return (
		<div class="row EvColorGrisLight">
			<div class="col-6 col-sm-4 col-md-3 ">
				<Link to="/">
					<img src="http://razona.cl/logo.png" class="img-fluid logoEV" alt="logo" />
				</Link>
			</div>
		</div>
	);
};

export default Header;
