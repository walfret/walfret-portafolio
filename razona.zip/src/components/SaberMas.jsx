import React from 'react';

const SaberMas = () => {
	return (
		<div class="row justify-content-center sabermas EvColorBlue text-white">
			<div class="col-12 col-md-6 text-center mt-4 sabermas-box">
				<h3 class="font-weight-bold">
					¿Quiere saber más sobre <br />esta votación o dejar registro <br />en el libro de observaciones?
				</h3>
				<div>
					<span class="linespanwhite mb-4" />
				</div>
			</div>
			<div class="col-12 col-md-6 text-center h5 ">
				<div class="row">
					<div class="col-6">
						<a href="">
							<img
								src="https://lidermundial.evoting.cl/static/media/ojo.e582f51f.svg"
								class="img-max-100"
								alt="Participación"
							/>
							<p class="font-weight-bold no-decoration">
								Revisar la<br /> participación{' '}
							</p>
						</a>
					</div>
					<div class="col-6">
						<a href="">
							<img
								src="https://lidermundial.evoting.cl/static/media/cuaderno.a73cd9ea.svg"
								class="img-max-100"
								alt="Registrar Observación"
							/>
							<p class="font-weight-bold no-decoration">
								Registrar una observación<br /> en el libro
							</p>
						</a>
					</div>
				</div>
			</div>
		</div>
	);
};

export default SaberMas;
