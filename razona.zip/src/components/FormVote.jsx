import React, { useState, useEffect } from 'react';
import {Modal, Button} from 'react-bootstrap'
const { validate, clean, format, getCheckDigit } = require('rut.js')


function generateUUID()
{
	var d = new Date().getTime();
	
	if( window.performance && typeof window.performance.now === "function" )
	{
		d += performance.now();
	}
	
	var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c)
	{
		var r = (d + Math.random()*16)%16 | 0;
		d = Math.floor(d/16);
		return (c=='x' ? r : (r&0x3|0x8)).toString(16);
	});

return uuid;
}


function MyVerticallyCenteredModal(props) {


	const [rut, setRut] = useState("");
	const [email, setEmail] = useState("");

	console.log(email)
	console.log(rut)

	function shoot() {
		

		if (localStorage.getItem('rut') == rut) {
			alert('ya has votado ')
		}else if (rut == '2.229.629-6k' && email == 'al.martin.aguilera.s@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut', rut );
		}else if (rut == '22296296-K' && email == 'al.martin.aguilera.s@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut', rut );
		}


		
		if (localStorage.getItem('rut1') == rut) {
			alert('ya has votado ')
		}else if (rut == '2.217.657-10' && email == 'al.vicente.arellano.l@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut1', rut );
		}else if (rut == '22176571-0' && email == 'al.vicente.arellano.l@lcdportales.cl'){
		alert('Votación exitosa, tu id es '+ generateUUID() )
		localStorage.setItem('rut1', rut );
	}

		if (localStorage.getItem('rut2') == rut) {
			alert('ya has votado ')
		}else if (rut == '2.238.166-30' && email == 'al.borja.armengod.t@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut2', rut );
		}else if (rut == '22381663-0' && email == 'al.borja.armengod.t@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut2', rut );
		}



		if (localStorage.getItem('rut3') == rut) {
			alert('ya has votado ')
		}else if (rut == '2.234.780-0k' && email == 'al.camilo.arroyo.s@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut3', rut );
		}else if (rut == '22347800-K' && email == 'al.camilo.arroyo.s@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut3', rut );
		}


		
		if (localStorage.getItem('rut4') == rut) {
			alert('ya has votado ')
		}else if (rut == '2.234.434-35' && email == 'al.matilda.bastias.p@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut4', rut );
		}else if (rut == '22344343-5' && email == 'al.matilda.bastias.p@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut4', rut );
		}

		if (localStorage.getItem('rut5') == rut) {
			alert('ya has votado ')
		}else if (rut == '2.242.314-23' && email == 'al.mateo.bravo.a@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut5', rut );
		}else if (rut == '22423142-3' && email == 'al.mateo.bravo.a@lcdportales.cl'){
		alert('Votación exitosa, tu id es '+ generateUUID() )
		localStorage.setItem('rut5', rut );
	}

		if (localStorage.getItem('rut6') == rut) {
			alert('ya has votado ')
		}else if (rut == '2.217.218-88' && email == 'al.tomas.bustamante.a@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut6', rut );
		}else if (rut == '22172188-8' && email == 'al.tomas.bustamante.a@lcdportales.cl'){
			alert('Votación exitosa, tu id es '+ generateUUID() )
			localStorage.setItem('rut6', rut );
		}

		

	  }



	  

	  











	return (
	  <Modal
		{...props}
		size="lg"
		aria-labelledby="contained-modal-title-vcenter"
		centered
	  >
		<Modal.Header closeButton>
		  <Modal.Title id="contained-modal-title-vcenter">
          Identificación
		  </Modal.Title>
		</Modal.Header>
		<Modal.Body>
		<div class="modal-body">
        <form id="castBallotForm" action="https://ballot-box.evoting.com/ticketcast?csrfToken=f2a8eb3f0b72996170fadf971e03edd7f00290cf-1620349033195-e624eb02c1d59af76a9bd353" method="POST" nonce="">
          <input type="hidden" name="ballot" value="eyJhbGciOiJFUzI1NiIsImp3ayI6eyJrdHkiOiJFQyIsImNydiI6IlAtMjU2IiwieCI6IlV4c1RBOGU1b0tSbUZNaXIyRjRoSXdDMnVuYkJna0pUeXdycWE5ekpXclUiLCJ5IjoiaDl4dnBzTzZyR21tM2dnYVZLZEFjRllySXNyWHFsVzRXY0RkQXlYaGpuNCJ9fQ.eyJiYWxsb3QiOnsiZWxlY3Rpb25faWQiOiJuY25GaDZwMCIsImFuc3dlcnMiOlt7ImVuY3J5cHRlZF9hbnN3ZXJfemtwIjp7ImVfcyI6W10sImFfcyI6W10sInpfcyI6W119LCJlbmNyeXB0ZWRfYmxhbmtzX3prcCI6eyJlX3MiOltdLCJhX3MiOltdLCJ6X3MiOltdfSwiZW5jcnlwdGVkX2JsYW5rcyI6Ik4yU29sb2E5SWVzQUxhUXdwMTREUmkrdjFlQUZpaUNGRVVOajN4UUVsU3ExdFpcL0J6VmN1OXozOHNTYkVmcGhycUJGc2RRKzZUem1Ba25cL2ttelFTZnR6TVBONmN1dEJRNmhlREVVK3YxckUyNGd6UE1pamVuZ09mbzBqZnlNVFVnTmM1TjV3SnlBVUg0YXI5QytQSFQ0bkl0cFdySlp3M0JSMGxQMis4RkhUOW0yK1wvem9jSnNPU1hwbUxBaUprQ3pyNUkrREI5dlZxNHRtYmhtYWs5dzJackJ0UmwzbEhZOWxzRzBHc3pvMVdURmt3VFNNcjRwaENGdjhhaVlBRDlUMms5OG1VOTBLZFwvcW42Z2F3QVJGUjArdzFkamNUT0E5eVFzQzBQOGM3SUZ0dEsyUUNSeUlKSENzSmNDZ2tOalhZNXYyM2hPN041SnBwK0twbTlLQnc9PSIsInF1ZXN0aW9uX2lkIjoiUTAxIiwiZW5jcnlwdGVkX2Fuc3dlciI6Ik4xUUlQcTdpNjJqdkhOWmY4NlJNVTcyc1pqNUxXNUpcL0ZBVEtTNzhhU3hVdzQwczl2Y3hrS2Z1WEF3RWlFXC9xQU9BSFVuWGV6Z3ZmT1dveFY4ZENhQzNTZzVOYjZKTUY0MVBxbUhHbHIrV3ZLMGVNRkxyYzBaOFJBXC8zNVV6Y0pJYjFWNHNOOXV5MWNVNEtCamxFcDBmVVBhKzEySHd6OGQ2dUtKZkdlT3NGNXNtSnBWTFg3Y01uWHg1WHNIN1RmalJuUjZEbjNTdGJmUk5zSWdwUkZnSVV2ZTIyeWNMZWlDK1FRdHVKWmc4TWJCQ3ViZkhJdkR2QUdyckJTWUZjdm9ZNnl1c3dJV3hqSEpvRTgzRlhDMXdkRDdZQ1JPNTI2WkpITVhYeHMrWVFxdTNodm41UFFaSkVjYXdFU0lxekk0bTR3c0tMc1k1cnhEWm5Wc09lYlArdz09In1dLCJkaXN0cmljdF9pZCI6IkQwMSJ9LCJzdWIiOiJjbC5ldm90aW5nLmJhbGxvdCIsImlzcyI6ImNsLmV2b3RpbmcuZW5jcnlwdGVyIiwiaWF0IjoxNjIwMzQ5MDMyfQ.71lLzyqXjpA8xvsMCVZErJDdyusbkkmP47_uDYqWG0Cxxy9N9fCVb0IKyxL_fW_TD1_tqyXMEhI5wn5aYq12Mw"/>
          <input id="ticket" type="hidden" name="ticket" value="none"/>
        </form>
        <form id="castForm" action="#" method="POST">
          <div class="row justify-content-center">
            <div class="col-12 col-sm-6">
              <div class="form-group">
                <label for="run">
                  Ingrese su RUT
                </label>
                <input id="run" class="form-control run" type="text" autofocus="autofocus" maxlength="12" name="user" value={format(rut)} placeholder="RUT (5.126.663-3)" onChange={e => setRut(e.target.value)} required="required"/>
                <div class="invalid-feedback">RUT incorrecto, verifique</div>
              </div>
              <div class="form-group">
                <label for="serial">
                  Correo institucional:
                </label>
                <input id="serial" class="form-control serial" autocomplete="off" type="text" name="password" placeholder="nombre@colegio.cl" onChange={e => setEmail(e.target.value)} required="required"/>
                <div class="invalid-feedback">Serial incorrecto, verifique</div>
              </div>
              <div class="row justify-content-center mb-2 mt-4">
                <div class="col-12 " style={{ display: 'flex', justifyContent: 'center' }}>
                  <input id="authFormSubmit" class="btn btn-lg EvColorBlue text-white" type="button" onClick={shoot} value="DEPOSITAR VOTO"/>
                </div>
              </div>
              <div class="row justify-content-center mb-4">
                <div class="col-12 text-center">
                  <button style={{ backgroundColor: '#E5ECF0' }} id="cancelButton" class="btn EvColorGrisLight mr-2" type="button" data-dismiss="modal">
                    CANCELAR
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center m-2">
            <div class="col-12 col-sm-5">
              <img class="img-fluid mx-auto d-block" src="https://vote.evoting.com/assets/images/ci_new_260px.png" />
            </div>
            <div class="col-12 col-sm-5">
              <img class="img-fluid mx-auto d-block" src="https://vote.evoting.com/assets/images/ci_old_206px.png" />
            </div>
          </div>
        </form>
      </div>
		</Modal.Body>
	  </Modal>
	);
  }


const FormVote = () => {

	const [ checked1, setChecked1 ] = useState(false);
	const handleClick1 = () => setChecked1(!checked1);
	const [ checked2, setChecked2 ] = useState(false);
	const handleClick2 = () => setChecked2(!checked2);
	const [ checked3, setChecked3 ] = useState(false);
	const handleClick3 = () => setChecked3(!checked3);
	
	const [modalShow, setModalShow] = React.useState(false);

	const [ countVote, setCountVote ] = useState(0);
	const [ nulos, setNulos] = useState('')

	useEffect(() => getRouteDirection());

	const getRouteDirection = () => {
		
		if (checked1) {
			console.log('Donalt Trump');
			setCountVote(1)
		}else if (checked2) {
			console.log('Jo Jorgensen');
			setCountVote(1)
		}else if (checked3) {
			console.log('Joe Biden');
			setCountVote(1)
		}else if (!checked1) {
			setCountVote(0)
		}else if (!checked2) {
			setCountVote(0)
		}else if (!checked3) {
			setCountVote(0)
		}

		if(checked1 && checked2){
			setNulos('voto nulo')
		}

		if(checked1 && checked3){
			setNulos('voto nulo')
		}

		if(checked2 && checked3){
			setNulos('voto nulo')
		}

		
		if(!checked1 && !checked2){
			setNulos('')
		}

		if(!checked1 && !checked3){
			setNulos('')
		}

		if(!checked2 && !checked3){
			setNulos('')
		}
	}





console.log(generateUUID())








	return (
		<>


		<div style={{ backgroundColor: 'white' }} class="row justify-content-center EvColorGrisLight">
			<div class="col-12 col-sm-11 col-md-9 col-lg-7">
				<form id="voteForm">
					<input type="hidden" name="district" value="D01" />
					<br />
					<div class="cross question" max-options="2" nullable="nullable">
						<input type="hidden" name="answers[0].question" value="Q01" />
						<div class="row mt-4">
							<div class="col-12 text-center">
								<h5>
									Elija a continuación un candidato presidencial
									{
										nulos == 'voto nulo' ? (<span style={{ backgroundColor: '#ffc107 !important' }} class="badge EvColor blur"> voto nulo</span>) : (<span class="badge EvColor blur"> ({countVote} de 1)</span>)
									}
									
								</h5>
							</div>
						</div>
						<div class="row justify-content-center">
							<div class="col-12 col-sm-6">
								<input type="hidden" name="answers[0].answer[2].position" value="2" />
								<input
									id="HoseSdek"
									class="ballot qoption"
									type="checkbox"
									name="answers[0].answer[2].value"
									value="1"
									onClick={handleClick1}
									checked={checked1}
								/>
								<label for="HoseSdek">
									<div class="row">
										<div class="col-4 text-right">
											<div class="marca blur" />
										</div>
										<div class="col-8">
											<div class="row h-100 align-items-center">
												<h6>Donalt Trump</h6>
											</div>
										</div>
									</div>
								</label>

								<input type="hidden" name="answers[0].answer[3].position" value="3" />
								<input
									id="eCXg8ipT"
									class="ballot qoption"
									type="checkbox"
									name="answers[0].answer[3].value"
									value="1"
									onClick={handleClick2}
									checked={checked2}
								/>
								<label for="eCXg8ipT">
									<div class="row">
										<div class="col-4 text-right">
											<div class="marca blur" />
										</div>
										<div class="col-8">
											<div class="row h-100 align-items-center">
												<h6>Jo Jorgensen</h6>
											</div>
										</div>
									</div>
								</label>
								<input type="hidden" name="answers[0].answer[4].position" value="4" />
								<input
									id="LqZGdhTs"
									class="ballot qoption"
									type="checkbox"
									name="answers[0].answer[4].value"
									value="1"
									onClick={handleClick3}
									checked={checked3}
								/>
								<label for="LqZGdhTs">
									<div class="row">
										<div class="col-4 text-right">
											<div class="marca blur" />
										</div>
										<div class="col-8">
											<div class="row h-100 align-items-center">
												<h6>Joe Biden</h6>
											</div>
										</div>
									</div>
								</label>
							</div>
						</div>
					</div>
					<hr />
					<br />
					<div class="row justify-content-center text-center mb-4">
						<div class="col-12">
							
							<Button id="closeVote" onClick={() => setModalShow(true)} class="btn btn-lg EvColorBlue text-white">
								CERRAR EL VOTO
							</Button>


	  <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
						</div>
					</div>

				</form>
			</div>
		</div>
		</>
	);
};

export default FormVote;
