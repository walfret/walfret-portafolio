import React from 'react';

const LogoInstitucion = () => {
	return (
		<div class="row justify-content-center">
			<div class="col-12 col-sm-11  text-center m-4 ">
				<img
					class="img-fluid logo"
					alt="Logo"
					src="https://s3.amazonaws.com/evoting/Demo+Colombia/tu-logo-aqui.png"
				/>
			</div>
		</div>
	);
};

export default LogoInstitucion;
