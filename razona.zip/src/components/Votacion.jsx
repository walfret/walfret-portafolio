import React from 'react';
import FormVote from './FormVote';

const Votacion = () => {
	return (
        <>
		<div>
			<div class="row justify-content-center EvColor text-white">
				<div class="col-12 col-sm-11 col-md-9 col-lg-7 pt-2 pb-2">
					<h4 class="m-0">Papeleta de votación</h4>
				</div>
			</div>
			<div class="row justify-content-center mt-3">
				<div class="col-12 col-sm-11 col-md-9 col-lg-7">
					<p>
						Marque sus preferencias haciendo clic en la línea horizontal al lado de cada opción. Una vez
						marcadas sus opciones, presione el botón "Cerrar el voto" ubicado al final de la página
					</p>
				</div>
			</div>
		</div>
        
        <FormVote />
        </>
	);
};

export default Votacion;
